package com.example.apnshortcut

import android.os.Bundle
import android.support.design.widget.Snackbar
import android.support.v7.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import android.view.Menu
import android.view.MenuItem
import com.example.apnshortcut.databinding.ActivityMainBinding

import android.content.Intent

import android.R
import android.provider.Settings
import android.telephony.SubscriptionManager
import android.view.View;




class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val intent = Intent(Settings.ACTION_APN_SETTINGS)
        intent.putExtra("sub_id", SubscriptionManager.getDefaultSubscriptionId());
        startActivity(intent);
    }

    /** Called when the user clicks the APN Settings button  */
    fun openAPNSettings(view: View?) {
        val intent = Intent(Settings.ACTION_APN_SETTINGS)
        intent.putExtra("sub_id", SubscriptionManager.getDefaultSubscriptionId());

        startActivity(intent);
    }
}